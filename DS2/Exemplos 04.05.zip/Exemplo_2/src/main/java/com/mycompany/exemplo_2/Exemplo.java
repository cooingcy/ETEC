package com.mycompany.exemplo_2;

//Importa as classes (classes primordiais para o código funcionar).
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//Declara a classe Exemplo que herda da classe JFrame
public class Exemplo extends JFrame{
    //Cria a estrutura das váriaveis (váriaveis de instancia ou atributos)
    JLabel rotulo1, rotulo2, rotulo3, rotulo4, exibir;
    JTextField texto1, texto2, texto3, texto4;
    JButton cadastrar;
    //Cria a estrutura do código
     public Exemplo(){
        //Metodo super, faz uma chamada implicita da classe JFrame
        super("Exemplo");
        //Classe container, extencia o objeo tela
        Container tela = getContentPane();
        //Seta a tela como nula
        setLayout(null);
        //Instancia os objetos criados
        rotulo1 = new JLabel("CEP: ");
        rotulo2 = new JLabel("Telefone: ");
        rotulo3 = new JLabel("CPF: ");
        rotulo4 = new JLabel("Data: ");
        
        //Instancia o objeto e define o tamanho
        texto1 = new JTextField(5);
        texto2 = new JTextField(5);
        texto3 = new JTextField(5);
        texto4 = new JTextField(5);
        exibir = new JLabel("");
        //Instancia o obejeto com nome somar
        cadastrar = new JButton("Cadastrar");
        
        //Seta a posição de cada objeto que instanciou
        rotulo1.setBounds(50,40,100,20);
        rotulo2.setBounds(50,80,100,20);
        rotulo3.setBounds(50,120,100,20);
        rotulo4.setBounds(50,160,100,20);
        texto1.setBounds(150,40,130,20);
        texto2.setBounds(150,80,130,20);
        texto3.setBounds(150,120,130,20);
        texto4.setBounds(150,160,130,20);
        exibir.setBounds(30,120,200,20);
        cadastrar.setBounds(155,200,100,20);
        
        //Define uma fonte
        texto1.setFont(new Font("Arial",Font.BOLD,12));
        texto2.setFont(new Font("Arial",Font.BOLD,12));
        texto3.setFont(new Font("Arial",Font.BOLD,12));
        texto4.setFont(new Font("Arial",Font.BOLD,12));
        
        //Metodo
        cadastrar.addActionListener(
                //
            new ActionListener(){
                //
                public void actionPerformed(ActionEvent e){
                //Cria as variaveis
                int dados1,dados2,dados3,dados4;
                //A variavel vai receber o que obter atraves pelo metedo getText
                dados1 = Integer.parseInt(texto1.getText());
                dados2 = Integer.parseInt(texto2.getText());
                dados3 = Integer.parseInt(texto1.getText());
                dados4 = Integer.parseInt(texto2.getText());
                //Seta o exibir como true
                exibir.setVisible(true);
                //Exibir em uma janela os dados
                JOptionPane.showMessageDialog(null,"CPF: " +dados1 + "\nTelefone: "+dados2 +"\nCPF: " +dados3 +"\nData: " +dados4);
                }
            }
        
        );
        
        //Torna o exibir como false novamente
        exibir.setVisible(false);
        //Adiciona cada obejeto no objeto tela.
        tela.add(rotulo1);
        tela.add(rotulo2);
        tela.add(rotulo3);
        tela.add(rotulo4);
        tela.add(texto1);
        tela.add(texto2);
        tela.add(texto3);
        tela.add(texto4);
        tela.add(exibir);
        tela.add(cadastrar);
        setSize(450,300);
        setVisible(true);
        setLocationRelativeTo(null);  
    }
    //Metodo main
    public static void main(String args[]){
        //Intancia o metodo
        Exemplo app = new Exemplo();
        //
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
     
     
}

