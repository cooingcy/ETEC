package com.mycompany.exemplo1;

//Importa as classes (classes primordiais para o código funcionar).
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//Declara a classe Exemplo que herda da classe JFrame
public class Exemplo extends JFrame{
    //Cria a estrutura das váriaveis (váriaveis de instancia ou atributos)
    JLabel rotulo1, rotulo2, exibir;
    JTextField texto1, texto2;
    JButton somar, subtrair, multiplicar, dividir;
    //Cria a estrutura do código
    public Exemplo(){
        //Metodo super, faz uma chamada implicita da classe JFrame
        super("Exemplo de soma");
        //Classe container, extencia o objeo tela
        Container tela = getContentPane();
        //Seta a tela como nula
        setLayout(null);
        //Instancia os objetos criados
        rotulo1 = new JLabel("1º Número:");
        rotulo2 = new JLabel("2º Número:");
        //Instancia o objeto e define o tamanho
        texto1 = new JTextField(5);
        texto2 = new JTextField(5);
        exibir = new JLabel("");
        //Instancia o obejeto com nome somar
        somar = new JButton("Somar");
        subtrair = new JButton("Subtrair");
        multiplicar = new JButton("Multiplicar");
        dividir = new JButton("Divir");
        
        //Seta a posição de cada objeto que instanciou
        rotulo1.setBounds(50,20,100,20);
        rotulo2.setBounds(50,60,100,20);
        texto1.setBounds(120,20,200,20);
        texto2.setBounds(120,60,200,20);
        exibir.setBounds(30,120,200,20);
        somar.setBounds(30,100,100,20);
        subtrair.setBounds(30,125,100,20);
        multiplicar.setBounds(30,150,100,20);
        dividir.setBounds(30,175,100,20);
        
        
        //Metodo
        somar.addActionListener(
                //
            new ActionListener(){
                //
                public void actionPerformed(ActionEvent e){
                    //Criou duas variaveis
                    int numero1,numero2,soma;
                    //Inicializa a variavel soma
                    soma = 0;
                    //A variavel numero 1 e numero2, vai receber o que obter atraves pelo metedo getText    
                    numero1 = Integer.parseInt(texto1.getText());
                    numero2 = Integer.parseInt(texto2.getText());
                    soma = numero1 + numero2;
                    //Seta o exibir como true
                    exibir.setVisible(true);
                    //
                    //exibir.setText("A soma é: "+soma);
                    //Exibir em uma janela o resultado
                    JOptionPane.showMessageDialog(null,"A soma é: " +soma);
                }
        
            }
        );
        subtrair.addActionListener(
                new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        int numero1, numero2, sub;
                        sub = 0;
                        numero1 = Integer.parseInt(texto1.getText());
                        numero2 = Integer.parseInt(texto2.getText());
                        sub = numero1 - numero2;
                        exibir.setVisible(true);
                        JOptionPane.showMessageDialog(null,"A subtração é: " +sub);
                    }
                }
        );
        multiplicar.addActionListener(
                new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        int numero1, numero2, multi;
                        multi = 0;
                        numero1 = Integer.parseInt(texto1.getText());
                        numero2 = Integer.parseInt(texto2.getText());
                        multi = numero1 * numero2;
                        exibir.setVisible(true);
                        JOptionPane.showMessageDialog(null,"A multiplicação é: " +multi);
                    }
                }
        );
        dividir.addActionListener(
                new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        int numero1, numero2, div;
                        div = 0;
                        numero1 = Integer.parseInt(texto1.getText());
                        numero2 = Integer.parseInt(texto2.getText());
                        div = numero1 / numero2;
                        exibir.setVisible(true);
                        JOptionPane.showMessageDialog(null,"A divsão é: " +div);
                    }
                }
        );
        
        //Torna o exibir como false novamente
        exibir.setVisible(false);
        
        //Adiciona cada obejeto no objeto tela.
        tela.add(rotulo1);
        tela.add(rotulo2);
        tela.add(texto1);
        tela.add(texto2);
        tela.add(exibir);
        tela.add(somar);
        tela.add(subtrair);
        tela.add(multiplicar);
        tela.add(dividir);
        
        //Define o tamanho 
        setSize(400,250);
        //Seta a visibiliade
        setVisible(true);
        setLocationRelativeTo(null);        
    }
    //Metodo main
    public static void main(String args[]){
        //Intancia o metodo
        Exemplo app = new Exemplo();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
