package com.mycompany.exemplo5;

//Importa as classes gráficas
import javax.swing.*;
import java.awt.*;

//Cria a classe que herda de JFrame
public class Exemplo extends JFrame{
    JButton botao;
    ImageIcon icone;
    public Exemplo(){
        //Define o nome da janela
        super("Exemplo com JButton");
        Container tela = getContentPane();
        setLayout(null);
        //Adiciona a imagem na janela
        icone = new ImageIcon("Thumbs_down.gif");
        botao = new JButton ("Thumbs_down",icone);
        //Define o tamanho do botão
        botao.setBounds(50,20,200,20);
        //Adiciona o botão na tela
        tela.add(botao);
        //Define o tamanho da janela
        setSize(300, 150);
        //Define a visibilidade da janela
        setVisible(true);
    }
    public static void main(String args[]){
        Exemplo app = new Exemplo();
        //Cria os botões de fechar... a página
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
