package com.mycompany.exemplo3;

//Importa as classes gráficas
import javax.swing.*;
import java.awt.*;

public class Exemplo extends JFrame{
    //
    JLabel imagem;
    
    //Metodo construtor
    public Exemplo(){
    //Define o nome da janela
    super("Uso da classe JLabel com imagem");
    Container tela = getContentPane();
    //Adiciona a imagem na janela
    ImageIcon icone = new ImageIcon("Back.png");
    imagem = new JLabel(icone);
    //Adiciona a imgem na tela
    tela.add(imagem);
    //Define o tamanho da janela
    setSize(500, 460);
    //Define a visibilidade da janela
    setVisible(true);
    }
    public static void main(String args[]){
        Exemplo app = new Exemplo();
        //Cria os botões de fechar... a página
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
