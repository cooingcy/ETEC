package com.mycompany.exemplo4;

//Importa as classes gráficas
import javax.swing.*;
import java.awt.*;

//Cria a classe que hgerda de JFrame
public class Exemplo extends JFrame{
    JButton botao;
    public Exemplo(){
        //Define o nome da janela
        super("Exemplo com JButoon");
        Container tela = getContentPane();
        setLayout(null);
        //Adiciona um texto no botão
        botao = new JButton ("Procurar");
        //Define o tamanho do botão
        botao.setBounds(50,20,100,20);
        //Adiciona o botao na tela
        tela.add(botao);
        //Define o tamanho da janela
        setSize(400,250);
        //Define a visibilidade da janela
        setVisible(true);
    }
    public static void main(String agrs[]){
        Exemplo app = new Exemplo();
        //Cria os botões de fechar... a página
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
