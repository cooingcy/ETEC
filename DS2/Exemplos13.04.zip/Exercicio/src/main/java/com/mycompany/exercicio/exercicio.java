package com.mycompany.exercicio;

//Importa as classes gráficas
import javax.swing.*;
import java.awt.*;

//Cria um aclasse que herda de jFrame
public class exercicio extends JFrame{
    JLabel rotulo1,rotulo2,rotulo3,rotulo4,rotulo5,rotulo6,rotulo7,cadastro;
    JTextField texto1,texto3,texto4,texto5,texto6,texto7,texto8;
    
    public exercicio(){
        //Define o nome da janela
        super("Exercício");
        Container tela = getContentPane();
        setLayout(null);
        //Define os nomes dos rotulos
            cadastro = new JLabel("Cadastro de Cliente");
            rotulo1 = new JLabel("Nome");
            rotulo2 = new JLabel("CPF");
            rotulo3 = new JLabel("RG");
            rotulo4 = new JLabel("Endereço");
            rotulo5 = new JLabel("Cidade");
            rotulo6 = new JLabel("Estado");
            rotulo7 = new JLabel("CEP:");
            //Define o tamanho dos textos
            texto1 = new JTextField(50);
            texto3 = new JTextField(7);
            texto4 = new JTextField(50);
            texto5 = new JTextField(50);
            texto6 = new JTextField(20);
            texto7 = new JTextField(10);
            texto8 = new JTextField(20);
            //Define o lugar dos rotulos e dos textos
            cadastro.setBounds(200,20,150,20);
            rotulo1.setBounds(50,50,80,20);
            rotulo2.setBounds(50,90,80,20);
            rotulo3.setBounds(50,130,80,20);
            rotulo4.setBounds(50,170,80,20);
            rotulo5.setBounds(50,210,80,20);
            rotulo6.setBounds(50,250,80,20);
            rotulo7.setBounds(50,290,80,20);
            texto1.setBounds(50,70,300,20);
            texto3.setBounds(50,110,200,20);
            texto4.setBounds(50,150,160,20);
            texto5.setBounds(50,190,300,20);
            texto6.setBounds(50,230,280,20);
            texto7.setBounds(50,270,250,20);
            texto8.setBounds(50,310,160,20);
            //Adiciona os rotulos e textos na janella
            tela.add(cadastro);
            tela.add(rotulo1);
            tela.add(rotulo2);
            tela.add(rotulo3);
            tela.add(rotulo4);
            tela.add(rotulo5);
            tela.add(rotulo6);
            tela.add(rotulo7);
            tela.add(texto1);
            tela.add(texto3);
            tela.add(texto4);
            tela.add(texto5);
            tela.add(texto6);
            tela.add(texto7);
            tela.add(texto8);
            //Define o tamanho da janela
            setSize(500,500);
            //Define a visibilidade ds janela
            setVisible(true);
            //Define a localização da janela
            setLocationRelativeTo(null);
    }
    public static void main(String args[]){
        exercicio app = new exercicio();
        //Cria os botões de fechar... a página
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
