package com.mycompany.exemplo_1;

//importa as classes gráficas
import javax.swing.*;
import java.awt.*;

//Cria uma classe que herda do JFrame
public class Exemplo extends JFrame{
    //Cria os rotulos
    JLabel rotulo1, rotulo2, rotulo3, rotulo4;
    //Método construtor
    public Exemplo(){
        //Nome da Janela
        super("Exemplo com Label");
        Container tela = getContentPane();
        setLayout(null);
            //Define os nomes dos rotulos
            rotulo1 = new JLabel("Nome");
            rotulo2 = new JLabel("Idade");
            rotulo3 = new JLabel("Telefone");
            rotulo4 = new JLabel("Celular");
            //Define o lugar dos rotulos
            rotulo1.setBounds(50,20,80,20);
            rotulo2.setBounds(50,60,80,20);
            rotulo3.setBounds(50,100,120,20);
            rotulo4.setBounds(50,140,80,20);
            //Define a cor dos rotulos
            rotulo1.setForeground(Color.red);
            rotulo2.setForeground(Color.blue);
            rotulo3.setForeground(new Color(190,152,142));
            rotulo4.setForeground(new Color(201,200,100));
            //Define uma font para os rotulos
            rotulo1.setFont(new Font("Arial",Font.BOLD,14));
            rotulo2.setFont(new Font("Comic",Font.BOLD,16));
            rotulo3.setFont(new Font("Courier",Font.BOLD,18));
            rotulo4.setFont(new Font("Times New Roman",Font.BOLD,20));
            //Adiciona os rotulos na tela
            tela.add(rotulo1);
            tela.add(rotulo2);
            tela.add(rotulo3);
            tela.add(rotulo4);
            //Define o tamanho da janela
            setSize(400,250);
            //Define a visibilidade da janela
            setVisible(true);
            //Define a localização da janela
            setLocationRelativeTo(null);
    }
    public static void main(String args[]){
        Exemplo app = new Exemplo();
        //Cria os botões de fechar... a página
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
